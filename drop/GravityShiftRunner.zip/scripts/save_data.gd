extends Node

const PATH := "user://gravity_shift.cfg"

var best_score := 0
var total_orbs := 0
var music_volume := 0.8
var sfx_volume := 1.0
var vibration := true
var quality := 2
var tutorial_seen := false

func _ready() -> void:
    load_data()

func load_data() -> void:
    var config := ConfigFile.new()
    if config.load(PATH) != OK:
        return
    best_score = config.get_value("player", "best_score", 0)
    total_orbs = config.get_value("player", "total_orbs", 0)
    tutorial_seen = config.get_value("player", "tutorial_seen", false)
    music_volume = config.get_value("settings", "music_volume", 0.8)
    sfx_volume = config.get_value("settings", "sfx_volume", 1.0)
    vibration = config.get_value("settings", "vibration", true)
    quality = config.get_value("settings", "quality", 2)

func save_data() -> void:
    var config := ConfigFile.new()
    config.set_value("player", "best_score", best_score)
    config.set_value("player", "total_orbs", total_orbs)
    config.set_value("player", "tutorial_seen", tutorial_seen)
    config.set_value("settings", "music_volume", music_volume)
    config.set_value("settings", "sfx_volume", sfx_volume)
    config.set_value("settings", "vibration", vibration)
    config.set_value("settings", "quality", quality)
    config.save(PATH)
