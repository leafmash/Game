class_name GameUI
extends CanvasLayer

signal play_pressed
signal pause_pressed
signal resume_pressed
signal restart_pressed
signal home_pressed
signal revive_pressed
signal settings_changed
signal tutorial_finished

const ACCENT := Color(0.1, 0.62, 0.9)
const MUTED := Color(0.2, 0.22, 0.42)
const DANGER := Color(0.85, 0.2, 0.35)

var root: Control
var safe: MarginContainer
var screens: Array[Control] = []
var hud: Control
var menu: Control
var pause_screen: Control
var over_screen: Control
var settings_screen: Control
var tutorial_screen: Control
var settings_return: Control
var score_label: Label
var combo_label: Label
var orbs_label: Label
var power_label: Label
var popup_label: Label
var best_label: Label
var menu_orbs_label: Label
var over_score: Label
var over_best: Label
var over_orbs: Label
var over_stats: Label
var revive_button: Button
var music_button: Button
var sfx_button: Button
var vibration_button: Button
var quality_button: Button
var popup_tween: Tween

func _ready() -> void:
    layer = 1
    root = Control.new()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.theme = build_theme()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    safe = MarginContainer.new()
    safe.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(safe)
    safe.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    build_hud()
    build_menu()
    build_pause()
    build_game_over()
    build_settings()
    build_tutorial()
    get_viewport().size_changed.connect(apply_safe_area)
    apply_safe_area()
    refresh_settings()

func build_theme() -> Theme:
    var theme := Theme.new()
    theme.default_font_size = 32
    return theme

func apply_safe_area() -> void:
    var window := DisplayServer.window_get_size()
    if window.x <= 0 or window.y <= 0:
        return
    var view := get_viewport().get_visible_rect().size
    var area := DisplayServer.get_display_safe_area()
    var scale_x := view.x / float(window.x)
    var scale_y := view.y / float(window.y)
    safe.add_theme_constant_override("margin_left", maxi(int(area.position.x * scale_x), 0) + 24)
    safe.add_theme_constant_override("margin_top", maxi(int(area.position.y * scale_y), 0) + 24)
    safe.add_theme_constant_override("margin_right", maxi(int((window.x - area.end.x) * scale_x), 0) + 24)
    safe.add_theme_constant_override("margin_bottom", maxi(int((window.y - area.end.y) * scale_y), 0) + 24)

func make_label(text: String, font_size: int, color: Color = Color.WHITE) -> Label:
    var label := Label.new()
    label.text = text
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_constant_override("outline_size", 6)
    label.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.05, 0.9))
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return label

func button_style(color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.set_corner_radius_all(30)
    style.set_border_width_all(3)
    style.border_color = color.lightened(0.45)
    style.set_content_margin_all(18)
    return style

func make_button(text: String, handler: Callable, accent: bool = true, width: float = 460.0) -> Button:
    var button := Button.new()
    button.text = text
    button.custom_minimum_size = Vector2(width, 100.0)
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", 40)
    var base := ACCENT if accent else MUTED
    button.add_theme_stylebox_override("normal", button_style(base))
    button.add_theme_stylebox_override("hover", button_style(base.lightened(0.1)))
    button.add_theme_stylebox_override("pressed", button_style(base.darkened(0.2)))
    button.add_theme_stylebox_override("disabled", button_style(Color(0.15, 0.16, 0.24)))
    button.add_theme_color_override("font_color", Color.WHITE)
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)
    button.add_theme_color_override("font_disabled_color", Color(0.5, 0.52, 0.62))
    button.pressed.connect(func() -> void:
        Sfx.play("click")
        handler.call()
    )
    button.button_down.connect(func() -> void: animate_button(button, 0.93))
    button.button_up.connect(func() -> void: animate_button(button, 1.0))
    button.resized.connect(func() -> void: button.pivot_offset = button.size / 2.0)
    return button

func animate_button(button: Button, target: float) -> void:
    create_tween().tween_property(button, "scale", Vector2.ONE * target, 0.08)

func make_screen(dim: bool) -> Control:
    var screen := Control.new()
    screen.visible = false
    root.add_child(screen)
    screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    if dim:
        var shade := ColorRect.new()
        shade.color = Color(0.0, 0.0, 0.03, 0.68)
        screen.add_child(shade)
        shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    screens.append(screen)
    return screen

func make_column(screen: Control, separation: int = 24) -> VBoxContainer:
    var center := CenterContainer.new()
    screen.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", separation)
    column.alignment = BoxContainer.ALIGNMENT_CENTER
    center.add_child(column)
    return column

func make_spacer(height: float) -> Control:
    var spacer := Control.new()
    spacer.custom_minimum_size = Vector2(0.0, height)
    spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return spacer

func show_only(target: Control, with_hud: bool = false) -> void:
    for screen in screens:
        screen.visible = screen == target
    hud.visible = with_hud
    if target != null:
        target.modulate.a = 0.0
        create_tween().tween_property(target, "modulate:a", 1.0, 0.25)

func build_hud() -> void:
    hud = Control.new()
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.visible = false
    safe.add_child(hud)
    var column := VBoxContainer.new()
    column.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(column)
    column.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    var top := HBoxContainer.new()
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    column.add_child(top)
    score_label = make_label("0", 68)
    score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    score_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(score_label)
    var pause_button := make_button("II", emit_pause, false, 100.0)
    top.add_child(pause_button)
    combo_label = make_label("", 44, Color(1.0, 0.85, 0.3))
    combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    column.add_child(combo_label)
    orbs_label = make_label("ORBS  0", 34, Color(1.0, 0.85, 0.3))
    orbs_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    column.add_child(orbs_label)
    power_label = make_label("", 34, Color(0.4, 1.0, 1.0))
    power_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
    column.add_child(power_label)
    popup_label = make_label("", 64, Color(1.0, 0.9, 0.3))
    popup_label.modulate.a = 0.0
    hud.add_child(popup_label)
    popup_label.set_anchor(SIDE_LEFT, 0.0)
    popup_label.set_anchor(SIDE_RIGHT, 1.0)
    popup_label.set_anchor(SIDE_TOP, 0.32)
    popup_label.set_anchor(SIDE_BOTTOM, 0.32)
    popup_label.offset_left = 0.0
    popup_label.offset_right = 0.0
    popup_label.offset_top = 0.0
    popup_label.offset_bottom = 0.0
    popup_label.grow_vertical = Control.GROW_DIRECTION_BOTH

func build_menu() -> void:
    menu = make_screen(false)
    var column := make_column(menu, 22)
    column.add_child(make_label("GRAVITY SHIFT", 72, Color(0.3, 0.95, 1.0)))
    column.add_child(make_label("RUNNER", 118, Color(1.0, 0.3, 0.9)))
    best_label = make_label("BEST  0", 40, Color(1.0, 0.85, 0.3))
    column.add_child(best_label)
    menu_orbs_label = make_label("ORBS  0", 34, Color(1.0, 0.85, 0.3))
    column.add_child(menu_orbs_label)
    column.add_child(make_spacer(50.0))
    column.add_child(make_button("PLAY", emit_play))
    column.add_child(make_button("SETTINGS", open_settings_from_menu, false))
    column.add_child(make_spacer(30.0))
    column.add_child(make_label("IMORA STUDIO", 26, Color(1.0, 1.0, 1.0, 0.55)))

func build_pause() -> void:
    pause_screen = make_screen(true)
    var column := make_column(pause_screen, 24)
    column.add_child(make_label("PAUSED", 90))
    column.add_child(make_spacer(20.0))
    column.add_child(make_button("RESUME", emit_resume))
    column.add_child(make_button("RESTART", emit_restart, false))
    column.add_child(make_button("SETTINGS", open_settings_from_pause, false))
    column.add_child(make_button("HOME", emit_home, false))

func build_game_over() -> void:
    over_screen = make_screen(true)
    var column := make_column(over_screen, 20)
    column.add_child(make_label("CRASHED", 90, Color(1.0, 0.35, 0.4)))
    over_score = make_label("0", 130)
    column.add_child(over_score)
    over_best = make_label("", 42, Color(1.0, 0.85, 0.3))
    column.add_child(over_best)
    over_orbs = make_label("", 36, Color(1.0, 0.85, 0.3))
    column.add_child(over_orbs)
    over_stats = make_label("", 28, Color(0.8, 0.88, 1.0))
    column.add_child(over_stats)
    column.add_child(make_spacer(20.0))
    revive_button = make_button("REVIVE", emit_revive)
    column.add_child(revive_button)
    column.add_child(make_button("RESTART", emit_restart, false))
    column.add_child(make_button("HOME", emit_home, false))

func build_settings() -> void:
    settings_screen = make_screen(true)
    var column := make_column(settings_screen, 22)
    column.add_child(make_label("SETTINGS", 80))
    column.add_child(make_spacer(10.0))
    music_button = make_button("", cycle_music, false, 560.0)
    sfx_button = make_button("", cycle_sfx, false, 560.0)
    vibration_button = make_button("", toggle_vibration, false, 560.0)
    quality_button = make_button("", cycle_quality, false, 560.0)
    column.add_child(music_button)
    column.add_child(sfx_button)
    column.add_child(vibration_button)
    column.add_child(quality_button)
    column.add_child(make_spacer(10.0))
    column.add_child(make_button("BACK", close_settings))

func build_tutorial() -> void:
    tutorial_screen = make_screen(true)
    var column := make_column(tutorial_screen, 20)
    column.add_child(make_label("HOW TO PLAY", 72, Color(0.3, 0.95, 1.0)))
    add_tutorial_row(column, "TAP RIGHT SIDE", "Rotate gravity clockwise")
    add_tutorial_row(column, "TAP LEFT SIDE", "Rotate gravity counter-clockwise")
    add_tutorial_row(column, "SWIPE UP", "Jump over low blocks")
    add_tutorial_row(column, "COLLECT ORBS", "Dodge red walls, lasers and bars")
    column.add_child(make_spacer(10.0))
    column.add_child(make_button("START", emit_tutorial_finished))

func add_tutorial_row(column: VBoxContainer, title: String, detail: String) -> void:
    var panel := PanelContainer.new()
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.1, 0.12, 0.3, 0.95)
    style.set_corner_radius_all(24)
    style.set_content_margin_all(20)
    panel.add_theme_stylebox_override("panel", style)
    panel.custom_minimum_size = Vector2(600.0, 0.0)
    var box := VBoxContainer.new()
    panel.add_child(box)
    box.add_child(make_label(title, 42, Color(0.3, 0.95, 1.0)))
    box.add_child(make_label(detail, 28))
    column.add_child(panel)
    var pulse := panel.create_tween().set_loops()
    pulse.tween_property(panel, "modulate:a", 0.7, 0.8)
    pulse.tween_property(panel, "modulate:a", 1.0, 0.8)

func emit_play() -> void:
    play_pressed.emit()

func emit_pause() -> void:
    pause_pressed.emit()

func emit_resume() -> void:
    resume_pressed.emit()

func emit_restart() -> void:
    restart_pressed.emit()

func emit_home() -> void:
    home_pressed.emit()

func emit_revive() -> void:
    revive_pressed.emit()

func emit_tutorial_finished() -> void:
    tutorial_finished.emit()

func open_settings_from_menu() -> void:
    open_settings(menu)

func open_settings_from_pause() -> void:
    open_settings(pause_screen)

func open_settings(from: Control) -> void:
    settings_return = from
    refresh_settings()
    show_only(settings_screen, from == pause_screen)

func close_settings() -> void:
    show_only(settings_return, settings_return == pause_screen)

func refresh_settings() -> void:
    music_button.text = "MUSIC  %d%%" % roundi(Save.music_volume * 100.0)
    sfx_button.text = "SOUND FX  %d%%" % roundi(Save.sfx_volume * 100.0)
    vibration_button.text = "VIBRATION  " + ("ON" if Save.vibration else "OFF")
    quality_button.text = "GRAPHICS  " + ["LOW", "MEDIUM", "HIGH"][Save.quality]

func step_volume(value: float) -> float:
    var next := value + 0.25
    return 0.0 if next > 1.01 else next

func cycle_music() -> void:
    Save.music_volume = step_volume(Save.music_volume)
    commit_settings()

func cycle_sfx() -> void:
    Save.sfx_volume = step_volume(Save.sfx_volume)
    commit_settings()

func toggle_vibration() -> void:
    Save.vibration = not Save.vibration
    commit_settings()

func cycle_quality() -> void:
    Save.quality = (Save.quality + 1) % 3
    commit_settings()

func commit_settings() -> void:
    Save.save_data()
    refresh_settings()
    settings_changed.emit()

func show_menu(best: int, orbs: int) -> void:
    best_label.text = "BEST  %d" % best
    menu_orbs_label.text = "ORBS  %d" % orbs
    show_only(menu)

func show_hud() -> void:
    show_only(null, true)

func show_pause() -> void:
    show_only(pause_screen, true)

func show_tutorial() -> void:
    show_only(tutorial_screen)

func show_game_over(score: int, best: int, is_best: bool, orbs: int, can_revive: bool, cost: int, stats: String) -> void:
    over_score.text = str(score)
    over_best.text = "NEW BEST!" if is_best else "BEST  %d" % best
    over_orbs.text = "ORBS  +%d" % orbs
    over_stats.text = stats
    revive_button.text = "REVIVE  (%d ORBS)" % cost
    revive_button.disabled = not can_revive
    show_only(over_screen)

func set_text(label: Label, value: String) -> void:
    if label.text != value:
        label.text = value

func update_hud(score: int, multiplier: int, orbs: int, status: String) -> void:
    set_text(score_label, str(score))
    set_text(combo_label, ("x%d COMBO" % multiplier) if multiplier > 1 else "")
    set_text(orbs_label, "ORBS  %d" % orbs)
    set_text(power_label, status)

func show_popup(text: String, color: Color = Color(1.0, 0.9, 0.3)) -> void:
    popup_label.text = text
    popup_label.add_theme_color_override("font_color", color)
    popup_label.modulate.a = 1.0
    popup_label.pivot_offset = popup_label.size / 2.0
    popup_label.scale = Vector2(1.3, 1.3)
    if popup_tween:
        popup_tween.kill()
    popup_tween = create_tween()
    popup_tween.tween_property(popup_label, "scale", Vector2.ONE, 0.15)
    popup_tween.tween_interval(0.6)
    popup_tween.tween_property(popup_label, "modulate:a", 0.0, 0.3)
