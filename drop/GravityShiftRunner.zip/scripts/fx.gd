class_name Fx
extends RefCounted

static func glow_material(color: Color, alpha: float = 1.0) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    material.albedo_color = Color(color.r, color.g, color.b, alpha)
    if alpha < 1.0:
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return material

static func solid_material(color: Color, roughness: float = 0.6) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    return material

static func lit_material(color: Color, metallic: float, roughness: float) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.metallic = metallic
    material.roughness = roughness
    return material

static func emissive_material(color: Color, energy: float = 2.0) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color.darkened(0.6)
    material.metallic = 0.6
    material.roughness = 0.2
    material.emission_enabled = true
    material.emission = color
    material.emission_energy_multiplier = energy
    return material

static func cylinder(parent: Node3D, radius: float, length: float, pos: Vector3, euler_degrees: Vector3, material: Material) -> MeshInstance3D:
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = length
    mesh.radial_segments = 10
    mesh.rings = 1
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.rotation_degrees = euler_degrees
    parent.add_child(instance)
    return instance

static func box(parent: Node3D, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    parent.add_child(instance)
    return instance

static func sphere(parent: Node3D, radius: float, pos: Vector3, material: Material) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 12
    mesh.rings = 6
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    parent.add_child(instance)
    return instance

static func burst(parent: Node, pos: Vector3, color: Color, amount: int, speed: float, size: float = 0.12, lifetime: float = 0.7) -> void:
    var particles := CPUParticles3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = size
    mesh.height = size * 2.0
    mesh.radial_segments = 6
    mesh.rings = 3
    mesh.material = glow_material(color)
    var curve := Curve.new()
    curve.add_point(Vector2(0.0, 1.0))
    curve.add_point(Vector2(1.0, 0.0))
    particles.mesh = mesh
    particles.scale_amount_curve = curve
    particles.amount = amount
    particles.lifetime = lifetime
    particles.one_shot = true
    particles.explosiveness = 1.0
    particles.direction = Vector3.UP
    particles.spread = 180.0
    particles.initial_velocity_min = speed * 0.4
    particles.initial_velocity_max = speed
    particles.gravity = Vector3.ZERO
    particles.position = pos
    particles.emitting = true
    parent.add_child(particles)
    particles.get_tree().create_timer(lifetime + 0.4).timeout.connect(particles.queue_free)
