extends Node3D

enum State { MENU, PLAYING, PAUSED, DEAD }

const HALF := 3.0
const BASE_SPEED := 16.0
const MAX_SPEED := 36.0
const MENU_SPEED := 9.0
const JUMP_VELOCITY := 11.0
const GRAVITY := 32.0
const JUMP_BUFFER := 0.12
const SHIFT_TIME := 0.28
const REVIVE_COST := 25
const TIER_SCORE := 500.0
const CAMERA_POSITION := Vector3(0.0, 0.2, 6.5)
const CAMERA_TARGET := Vector3(0.0, -2.2, -8.0)

var state: State = State.MENU
var world: Node3D
var track: Track
var runner: Runner
var camera: Camera3D
var environment: Environment
var speed_lines: CPUParticles3D
var overlay: ColorRect
var overlay_material: ShaderMaterial
var ui: GameUI
var rotation_tween: Tween
var aberration_tween: Tween
var speed := BASE_SPEED
var run_time := 0.0
var score := 0.0
var orbs_run := 0
var orbs_banked := 0
var combo := 0
var combo_timer := 0.0
var gravity_steps := 0
var surface := 0
var previous_surface := 0
var since_shift := 10.0
var height := 0.0
var vertical_velocity := 0.0
var jump_buffer := 0.0
var shield_active := false
var slow_timer := 0.0
var magnet_timer := 0.0
var tier := 0
var revived := false
var shake := 0.0
var dead_timer := 0.0
var game_over_shown := false
var finished_score := 0
var new_best := false
var pointer_start := Vector2.ZERO
var pointer_active := false
var swipe_used := false
var elapsed := 0.0
var menu_sway := 1.0

func _ready() -> void:
    randomize()
    build_environment()
    build_world()
    build_overlay()
    build_ui()
    apply_quality()
    show_menu()

func build_environment() -> void:
    environment = Environment.new()
    environment.background_mode = Environment.BG_COLOR
    environment.background_color = Color(0.02, 0.03, 0.08)
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.55, 0.6, 0.85)
    environment.ambient_light_energy = 0.7
    environment.fog_enabled = true
    environment.fog_light_color = Color(0.02, 0.03, 0.08)
    environment.fog_density = 0.02
    environment.glow_enabled = true
    environment.glow_intensity = 0.9
    environment.glow_bloom = 0.15
    environment.glow_hdr_threshold = 0.75
    var world_environment := WorldEnvironment.new()
    world_environment.environment = environment
    add_child(world_environment)

func build_world() -> void:
    world = Node3D.new()
    add_child(world)
    track = Track.new()
    world.add_child(track)
    track.player_hit.connect(on_player_hit)
    track.orb_collected.connect(on_orb)
    track.power_collected.connect(on_power)
    track.row_passed.connect(on_row_passed)
    runner = Runner.new()
    add_child(runner)
    runner.position = Vector3(0.0, -HALF, 0.0)
    camera = Camera3D.new()
    camera.keep_aspect = Camera3D.KEEP_WIDTH
    camera.fov = 68.0
    camera.near = 0.1
    camera.far = 160.0
    add_child(camera)
    camera.position = CAMERA_POSITION
    camera.look_at(CAMERA_TARGET, Vector3.UP)
    var light := DirectionalLight3D.new()
    light.light_energy = 0.9
    light.rotation_degrees = Vector3(-35.0, -15.0, 0.0)
    add_child(light)
    build_speed_lines()

func build_speed_lines() -> void:
    speed_lines = CPUParticles3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.03, 0.03, 1.6)
    mesh.material = Fx.glow_material(Color(0.7, 0.9, 1.0), 0.6)
    speed_lines.mesh = mesh
    speed_lines.amount = 36
    speed_lines.lifetime = 0.8
    speed_lines.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    speed_lines.emission_box_extents = Vector3(HALF - 0.3, HALF - 0.3, 1.0)
    speed_lines.direction = Vector3(0.0, 0.0, 1.0)
    speed_lines.spread = 0.0
    speed_lines.initial_velocity_min = 45.0
    speed_lines.initial_velocity_max = 60.0
    speed_lines.gravity = Vector3.ZERO
    speed_lines.position = Vector3(0.0, 0.0, -34.0)
    speed_lines.emitting = false
    add_child(speed_lines)

func build_overlay() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 0
    add_child(layer)
    overlay = ColorRect.new()
    overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay_material = ShaderMaterial.new()
    overlay_material.shader = load("res://shaders/screen_fx.gdshader")
    overlay.material = overlay_material
    layer.add_child(overlay)
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func build_ui() -> void:
    ui = GameUI.new()
    add_child(ui)
    ui.play_pressed.connect(start_game)
    ui.pause_pressed.connect(pause_game)
    ui.resume_pressed.connect(resume_game)
    ui.restart_pressed.connect(begin_run)
    ui.home_pressed.connect(show_menu)
    ui.revive_pressed.connect(revive)
    ui.settings_changed.connect(on_settings_changed)
    ui.tutorial_finished.connect(on_tutorial_finished)

func apply_quality() -> void:
    var quality: int = Save.quality
    overlay.visible = quality >= 1
    environment.glow_enabled = quality >= 2
    speed_lines.amount = [16, 28, 40][quality]
    Sfx.apply_volumes()

func on_settings_changed() -> void:
    apply_quality()

func haptic(milliseconds: int) -> void:
    if Save.vibration:
        Input.vibrate_handheld(milliseconds)

func multiplier() -> int:
    return mini(1 + floori(combo / 4.0), 10)

func show_menu() -> void:
    state = State.MENU
    tier = 0
    track.reset()
    track.spawning = false
    track.collisions = false
    track.tier = 0
    apply_tier_palette(false)
    if rotation_tween:
        rotation_tween.kill()
    world.rotation.z = 0.0
    gravity_steps = 0
    surface = 0
    height = 0.0
    runner.reset()
    runner.position = Vector3(0.0, -HALF, 0.0)
    speed_lines.emitting = false
    Sfx.stop_music()
    ui.show_menu(Save.best_score, Save.total_orbs)

func start_game() -> void:
    if Save.tutorial_seen:
        begin_run()
    else:
        ui.show_tutorial()

func on_tutorial_finished() -> void:
    Save.tutorial_seen = true
    Save.save_data()
    begin_run()

func begin_run() -> void:
    state = State.PLAYING
    speed = BASE_SPEED
    run_time = 0.0
    score = 0.0
    orbs_run = 0
    orbs_banked = 0
    combo = 0
    combo_timer = 0.0
    gravity_steps = 0
    surface = 0
    previous_surface = 0
    since_shift = 10.0
    height = 0.0
    vertical_velocity = 0.0
    jump_buffer = 0.0
    shield_active = false
    slow_timer = 0.0
    magnet_timer = 0.0
    tier = 0
    revived = false
    game_over_shown = false
    pointer_active = false
    shake = 0.0
    if rotation_tween:
        rotation_tween.kill()
    world.rotation.z = 0.0
    runner.reset()
    runner.position = Vector3(0.0, -HALF, 0.0)
    track.reset()
    track.spawning = true
    track.collisions = true
    track.tier = 0
    apply_tier_palette(false)
    speed_lines.emitting = true
    Sfx.start_music()
    ui.show_hud()

func pause_game() -> void:
    if state != State.PLAYING:
        return
    state = State.PAUSED
    pointer_active = false
    Sfx.pause_music(true)
    ui.show_pause()

func resume_game() -> void:
    if state != State.PAUSED:
        return
    state = State.PLAYING
    pointer_active = false
    Sfx.pause_music(false)
    ui.show_hud()

func revive() -> void:
    if revived or Save.total_orbs < REVIVE_COST:
        return
    revived = true
    Save.total_orbs -= REVIVE_COST
    Save.save_data()
    game_over_shown = false
    run_time = maxf(run_time - 6.0, 0.0)
    track.clear_ahead(60.0)
    track.collisions = true
    runner.revive()
    shield_active = true
    runner.set_shield(true)
    height = 0.0
    vertical_velocity = 0.0
    state = State.PLAYING
    speed_lines.emitting = true
    Sfx.start_music()
    ui.show_hud()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
        pause_game()
    elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
        match state:
            State.PLAYING:
                pause_game()
            State.PAUSED:
                resume_game()
            State.DEAD:
                show_menu()
            State.MENU:
                get_tree().quit()

func _unhandled_input(event: InputEvent) -> void:
    if state != State.PLAYING:
        return
    if event is InputEventMouseButton:
        var button_event := event as InputEventMouseButton
        if button_event.button_index != MOUSE_BUTTON_LEFT:
            return
        if button_event.pressed:
            pointer_start = button_event.position
            pointer_active = true
            swipe_used = false
        elif pointer_active:
            pointer_active = false
            if not swipe_used:
                var width := get_viewport().get_visible_rect().size.x
                shift_gravity(1 if button_event.position.x > width * 0.5 else -1)
    elif event is InputEventMouseMotion and pointer_active and not swipe_used:
        var motion_event := event as InputEventMouseMotion
        var travel := motion_event.position - pointer_start
        if travel.y < -80.0 and absf(travel.y) > absf(travel.x):
            swipe_used = true
            jump_buffer = JUMP_BUFFER
    elif event is InputEventKey:
        var key_event := event as InputEventKey
        if not key_event.pressed or key_event.echo:
            return
        match key_event.keycode:
            KEY_LEFT, KEY_A:
                shift_gravity(-1)
            KEY_RIGHT, KEY_D:
                shift_gravity(1)
            KEY_UP, KEY_W, KEY_SPACE:
                jump_buffer = JUMP_BUFFER

func shift_gravity(direction: int) -> void:
    previous_surface = surface
    gravity_steps += direction
    surface = posmod(gravity_steps, 4)
    since_shift = 0.0
    height = 0.0
    vertical_velocity = 0.0
    if rotation_tween:
        rotation_tween.kill()
    rotation_tween = create_tween()
    rotation_tween.tween_property(world, "rotation:z", -gravity_steps * PI * 0.5, SHIFT_TIME).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    runner.flip()
    Sfx.play("shift")
    haptic(25)
    kick_aberration()

func kick_aberration() -> void:
    if aberration_tween:
        aberration_tween.kill()
    aberration_tween = create_tween()
    aberration_tween.tween_method(set_aberration, 0.04, 0.0, 0.35)

func set_aberration(value: float) -> void:
    overlay_material.set_shader_parameter("aberration", value)

func _process(delta: float) -> void:
    elapsed += delta
    match state:
        State.MENU:
            update_menu(delta)
        State.PLAYING:
            update_play(delta)
        State.DEAD:
            update_dead(delta)
    update_camera(delta)

func update_menu(delta: float) -> void:
    world.rotation.z += delta * 0.2
    track.advance(delta, MENU_SPEED)
    runner.animate(delta, MENU_SPEED, false)

func update_jump(delta: float) -> void:
    jump_buffer = maxf(jump_buffer - delta, 0.0)
    var grounded := height <= 0.001 and vertical_velocity <= 0.0
    if grounded and jump_buffer > 0.0:
        vertical_velocity = JUMP_VELOCITY
        jump_buffer = 0.0
        grounded = false
        Sfx.play("jump")
        haptic(15)
    if not grounded:
        vertical_velocity -= GRAVITY * delta
        height += vertical_velocity * delta
        if height <= 0.0:
            height = 0.0
            vertical_velocity = 0.0
    runner.position.y = -HALF + height

func update_play(delta: float) -> void:
    run_time += delta
    speed = minf(BASE_SPEED + run_time * 0.3, MAX_SPEED)
    var move_speed := speed * (0.55 if slow_timer > 0.0 else 1.0)
    since_shift += delta
    update_jump(delta)
    track.player_surface = surface
    track.previous_surface = previous_surface
    track.player_height = height
    track.since_shift = since_shift
    track.magnet = magnet_timer > 0.0
    track.tier = tier
    track.advance(delta, move_speed)
    if state != State.PLAYING:
        return
    score += delta * move_speed * 0.5 * multiplier()
    update_timers(delta)
    update_tier()
    runner.animate(delta, move_speed, height > 0.01)
    Sfx.set_intensity(inverse_lerp(BASE_SPEED, MAX_SPEED, speed))
    ui.update_hud(int(score), multiplier(), orbs_run, power_status())

func update_timers(delta: float) -> void:
    slow_timer = maxf(slow_timer - delta, 0.0)
    magnet_timer = maxf(magnet_timer - delta, 0.0)
    if combo > 0:
        combo_timer -= delta
        if combo_timer <= 0.0:
            combo = 0

func update_tier() -> void:
    var new_tier := int(score / TIER_SCORE)
    if new_tier == tier:
        return
    tier = new_tier
    apply_tier_palette(true)
    ui.show_popup("ZONE %d" % (tier + 1), Color(0.4, 1.0, 1.0))
    Sfx.play("power", 0.8)

func apply_tier_palette(animated: bool) -> void:
    var colors := Track.palette(tier)
    var background: Color = colors["background"]
    track.apply_palette(tier, 1.5 if animated else 0.0)
    if animated:
        var tween := create_tween().set_parallel(true)
        tween.tween_property(environment, "background_color", background, 1.5)
        tween.tween_property(environment, "fog_light_color", background, 1.5)
    else:
        environment.background_color = background
        environment.fog_light_color = background

func power_status() -> String:
    var parts := PackedStringArray()
    if shield_active:
        parts.append("SHIELD")
    if slow_timer > 0.0:
        parts.append("SLOW %.0f" % ceilf(slow_timer))
    if magnet_timer > 0.0:
        parts.append("MAGNET %.0f" % ceilf(magnet_timer))
    return "   ".join(parts)

func update_dead(delta: float) -> void:
    dead_timer += delta
    var drift := maxf(0.0, 1.0 - dead_timer * 1.5) * speed * 0.3
    track.advance(delta, drift)
    if dead_timer > 1.0 and not game_over_shown:
        game_over_shown = true
        var can_revive := not revived and Save.total_orbs >= REVIVE_COST
        ui.show_game_over(finished_score, Save.best_score, new_best, orbs_run, can_revive, REVIVE_COST)

func update_camera(delta: float) -> void:
    var target_fov := 68.0 + clampf((speed - BASE_SPEED) * 0.6, 0.0, 12.0)
    camera.fov = lerpf(camera.fov, target_fov, minf(3.0 * delta, 1.0))
    var sway_target := 1.0 if state == State.MENU else 0.0
    menu_sway = lerpf(menu_sway, sway_target, minf(2.0 * delta, 1.0))
    camera.position = CAMERA_POSITION + Vector3(sin(elapsed * 0.6) * 0.5, cos(elapsed * 0.45) * 0.3, 0.0) * menu_sway
    shake = maxf(shake - delta * 2.5, 0.0)
    camera.h_offset = randf_range(-1.0, 1.0) * shake * 0.25
    camera.v_offset = randf_range(-1.0, 1.0) * shake * 0.25
    var vignette := 0.15 + clampf((speed - BASE_SPEED) / 20.0, 0.0, 1.0) * 0.5
    overlay_material.set_shader_parameter("vignette", vignette)

func on_player_hit(_kind: int) -> void:
    if shield_active:
        shield_active = false
        runner.set_shield(false)
        Sfx.play("shield_break")
        shake = 0.6
        haptic(60)
        Fx.burst(self, runner.position + Vector3(0.0, 0.8, 0.0), Color(0.2, 0.9, 1.0), 24, 7.0, 0.1, 0.7)
        return
    crash()

func crash() -> void:
    state = State.DEAD
    dead_timer = 0.0
    track.collisions = false
    runner.crash()
    var center := runner.position + Vector3(0.0, 0.8, 0.0)
    Fx.burst(self, center, Color(1.0, 0.3, 0.2), 36, 9.0, 0.14, 1.0)
    Fx.burst(self, center, Color(1.0, 1.0, 1.0), 18, 6.0, 0.1, 0.8)
    Sfx.play("crash")
    Sfx.duck_music()
    shake = 1.0
    haptic(220)
    speed_lines.emitting = false
    finished_score = int(score)
    new_best = finished_score > Save.best_score
    if new_best:
        Save.best_score = finished_score
    Save.total_orbs += orbs_run - orbs_banked
    orbs_banked = orbs_run
    Save.save_data()

func on_orb() -> void:
    orbs_run += 1
    combo += 1
    combo_timer = 4.0
    score += 10.0 * multiplier()
    Sfx.play("orb", 1.0 + minf(combo * 0.03, 0.6))
    haptic(8)

func on_power(kind: int) -> void:
    match kind:
        Track.Power.SHIELD:
            shield_active = true
            runner.set_shield(true)
            ui.show_popup("SHIELD", Color(0.2, 0.9, 1.0))
        Track.Power.SLOW:
            slow_timer = 5.0
            ui.show_popup("SLOW TIME", Color(0.75, 0.5, 1.0))
        Track.Power.MAGNET:
            magnet_timer = 7.0
            ui.show_popup("MAGNET", Color(0.3, 1.0, 0.4))
    Sfx.play("power")
    haptic(20)

func on_row_passed(near_miss: bool) -> void:
    if not near_miss:
        return
    combo += 3
    combo_timer = 4.0
    score += 25.0 * multiplier()
    shake = maxf(shake, 0.25)
    ui.show_popup("CLOSE CALL!")
    Sfx.play("near")
    haptic(12)
