class_name Track
extends Node3D

signal orb_collected
signal power_collected(kind: int)
signal player_hit(kind: int)
signal row_passed(near_miss: bool)

enum Kind { LOW, HIGH, LASER, SPINNER, ORB, POWER, GAP }
enum Power { SHIELD, SLOW, MAGNET }

const HALF := 3.0
const SEGMENT_LENGTH := 16.0
const SEGMENT_COUNT := 9
const SPAWN_AHEAD := 108.0
const DESPAWN_BEHIND := 16.0
const LASER_PERIOD := 2.2
const SPIN_RATE := 1.7
const FIRST_ROW_Z := -70.0

class Item:
    var kind := 0
    var surface := 0
    var z := 0.0
    var node: Node3D
    var visual: Node3D
    var done := false
    var collected := false
    var phase := 0.0
    var spin := 0.0
    var height := 0.0
    var power := 0

class Row:
    var z := 0.0
    var blocked: Array[int] = []
    var lows: Array[int] = []
    var judged := false

var spawning := false
var collisions := true
var tier := 0
var detail := 2
var player_surface := 0
var previous_surface := 0
var player_height := 0.0
var since_shift := 10.0
var magnet := false
var clock := 0.0
var current_speed := 16.0
var segments: Array[Node3D] = []
var trim_nodes: Array[Node3D] = []
var cable_nodes: Array[Node3D] = []
var items: Array[Item] = []
var rows: Array[Row] = []
var far_z := 0.0
var next_row_z := FIRST_ROW_Z
var last_row_z := 0.0
var last_safe := 0
var palette_tween: Tween
var panel_albedo: Texture2D
var panel_normal: Texture2D
var panel_material: StandardMaterial3D
var edge_material: StandardMaterial3D
var ring_material: StandardMaterial3D
var line_material: StandardMaterial3D
var frame_material: StandardMaterial3D
var cable_material: StandardMaterial3D
var pit_material: StandardMaterial3D
var hazard_red: StandardMaterial3D
var hazard_amber: StandardMaterial3D
var low_material: StandardMaterial3D
var hot_material: StandardMaterial3D
var danger_material: StandardMaterial3D
var laser_material: StandardMaterial3D
var laser_halo_material: StandardMaterial3D
var orb_core_material: StandardMaterial3D
var orb_shell_material: StandardMaterial3D
var power_materials: Array[StandardMaterial3D] = []
var power_shells: Array[StandardMaterial3D] = []

static func palette(index: int) -> Dictionary:
    var list: Array[Dictionary] = [
        {"panel": Color(0.2, 0.24, 0.36), "edge": Color(0.1, 0.9, 1.0), "background": Color(0.02, 0.03, 0.08)},
        {"panel": Color(0.3, 0.2, 0.36), "edge": Color(1.0, 0.2, 0.9), "background": Color(0.06, 0.02, 0.08)},
        {"panel": Color(0.18, 0.32, 0.26), "edge": Color(0.4, 1.0, 0.45), "background": Color(0.01, 0.06, 0.05)},
        {"panel": Color(0.36, 0.26, 0.2), "edge": Color(1.0, 0.55, 0.15), "background": Color(0.08, 0.03, 0.02)},
        {"panel": Color(0.28, 0.3, 0.38), "edge": Color(0.75, 0.82, 1.0), "background": Color(0.05, 0.05, 0.1)}
    ]
    return list[posmod(index, list.size())]

func _ready() -> void:
    make_materials()
    build_segments()
    apply_palette(0, 0.0)
    set_detail(detail)

func make_materials() -> void:
    var first := Track.palette(0)
    var textures := Surfaces.panel_textures()
    panel_albedo = textures[0]
    panel_normal = textures[1]
    panel_material = Fx.lit_material(first["panel"], 0.75, 0.42)
    panel_material.uv1_scale = Vector3(0.25, 0.25, 0.25)
    panel_material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    edge_material = Fx.glow_material(first["edge"])
    ring_material = Fx.glow_material(first["edge"])
    line_material = Fx.glow_material(first["edge"])
    frame_material = Fx.lit_material(Color(0.1, 0.12, 0.18), 0.85, 0.35)
    cable_material = Fx.lit_material(Color(0.05, 0.05, 0.07), 0.3, 0.5)
    pit_material = Fx.lit_material(Color(0.0, 0.0, 0.0), 0.0, 1.0)
    hazard_red = Surfaces.hazard(Color(1.0, 0.15, 0.2), Color(0.08, 0.08, 0.1))
    hazard_amber = Surfaces.hazard(Color(1.0, 0.6, 0.05), Color(0.08, 0.08, 0.1))
    low_material = Fx.glow_material(Color(1.0, 0.6, 0.1))
    hot_material = Fx.glow_material(Color(1.0, 0.92, 0.92))
    danger_material = Fx.glow_material(Color(1.0, 0.18, 0.3))
    laser_material = Fx.glow_material(Color(1.0, 0.2, 0.9))
    laser_halo_material = Fx.glow_material(Color(1.0, 0.2, 0.9), 0.3)
    orb_core_material = Fx.glow_material(Color(1.0, 0.9, 0.4))
    orb_shell_material = Fx.glow_material(Color(1.0, 0.75, 0.15), 0.35)
    var power_colors := [Color(0.2, 0.9, 1.0), Color(0.7, 0.4, 1.0), Color(0.3, 1.0, 0.4)]
    for color: Color in power_colors:
        power_materials.append(Fx.glow_material(color))
        power_shells.append(Fx.glow_material(color, 0.3))

func set_detail(level: int) -> void:
    detail = level
    var textured := level >= 1
    panel_material.albedo_texture = panel_albedo if textured else null
    panel_material.normal_enabled = textured
    panel_material.normal_texture = panel_normal if textured else null
    panel_material.uv1_triplanar = textured
    for node in trim_nodes:
        node.visible = level >= 1
    for node in cable_nodes:
        node.visible = level >= 2

func apply_palette(index: int, duration: float) -> void:
    var colors := Track.palette(index)
    var edge: Color = colors["edge"]
    var line := edge.darkened(0.45)
    if palette_tween:
        palette_tween.kill()
    if duration <= 0.0:
        panel_material.albedo_color = colors["panel"]
        edge_material.albedo_color = edge
        ring_material.albedo_color = edge
        line_material.albedo_color = line
        return
    palette_tween = create_tween().set_parallel(true)
    palette_tween.tween_property(panel_material, "albedo_color", colors["panel"], duration)
    palette_tween.tween_property(edge_material, "albedo_color", edge, duration)
    palette_tween.tween_property(ring_material, "albedo_color", edge, duration)
    palette_tween.tween_property(line_material, "albedo_color", line, duration)

func build_segments() -> void:
    for i in SEGMENT_COUNT:
        var segment := Node3D.new()
        add_child(segment)
        for surface in 4:
            var holder := Node3D.new()
            holder.rotation.z = surface * PI * 0.5
            segment.add_child(holder)
            Fx.box(holder, Vector3(HALF * 2.0 + 0.4, 0.2, SEGMENT_LENGTH), Vector3(0.0, -HALF - 0.1, 0.0), panel_material)
            Fx.box(holder, Vector3(HALF * 2.0, 0.1, 0.35), Vector3(0.0, -HALF + 0.03, -SEGMENT_LENGTH * 0.5 + 0.2), ring_material)
            Fx.box(holder, Vector3(0.16, 0.16, SEGMENT_LENGTH), Vector3(HALF - 0.08, -HALF + 0.08, 0.0), edge_material)
            Fx.box(holder, Vector3(0.08, 0.05, SEGMENT_LENGTH), Vector3(0.0, -HALF + 0.03, 0.0), line_material)
            build_trim(holder)
        segments.append(segment)
    reset_segments()

func build_trim(holder: Node3D) -> void:
    var tray := Fx.box(holder, Vector3(0.5, 0.3, SEGMENT_LENGTH - 1.0), Vector3(-2.45, -HALF + 0.15, 0.0), frame_material)
    var brace_left := Fx.box(holder, Vector3(0.7, 0.8, 0.6), Vector3(-2.65, -HALF + 0.4, -SEGMENT_LENGTH * 0.5 + 0.5), frame_material)
    var brace_right := Fx.box(holder, Vector3(0.7, 0.8, 0.6), Vector3(2.65, -HALF + 0.4, -SEGMENT_LENGTH * 0.5 + 0.5), frame_material)
    trim_nodes.append(tray)
    trim_nodes.append(brace_left)
    trim_nodes.append(brace_right)
    var cable_a := Fx.cylinder(holder, 0.07, SEGMENT_LENGTH - 1.0, Vector3(-2.55, -HALF + 0.38, 0.0), Vector3(90.0, 0.0, 0.0), cable_material)
    var cable_b := Fx.cylinder(holder, 0.07, SEGMENT_LENGTH - 1.0, Vector3(-2.35, -HALF + 0.38, 0.0), Vector3(90.0, 0.0, 0.0), cable_material)
    var indicator := Fx.box(holder, Vector3(0.12, 0.12, 0.12), Vector3(2.65, -HALF + 0.85, -SEGMENT_LENGTH * 0.5 + 0.5), edge_material)
    cable_nodes.append(cable_a)
    cable_nodes.append(cable_b)
    cable_nodes.append(indicator)

func reset_segments() -> void:
    for i in segments.size():
        segments[i].position.z = SEGMENT_LENGTH * 0.5 - i * SEGMENT_LENGTH
    far_z = segments[segments.size() - 1].position.z

func reset() -> void:
    for item in items:
        item.node.queue_free()
    items.clear()
    rows.clear()
    position.z = 0.0
    clock = 0.0
    next_row_z = FIRST_ROW_Z
    last_row_z = 0.0
    last_safe = 0
    reset_segments()

func clear_ahead(distance: float) -> void:
    for index in range(items.size() - 1, -1, -1):
        var item := items[index]
        var relative := item.z + position.z
        var pickup := item.kind == Kind.ORB or item.kind == Kind.POWER
        if not pickup and relative > -distance and relative < 6.0:
            item.node.queue_free()
            items.remove_at(index)
    for row in rows:
        if row.z + position.z > -distance:
            row.judged = true

func advance(delta: float, speed: float) -> void:
    clock += delta
    current_speed = speed
    position.z += speed * delta
    recycle_segments()
    if spawning:
        generate()
    update_items(delta)
    judge_rows()
    clean_rows()

func recycle_segments() -> void:
    for segment in segments:
        if segment.position.z + position.z > DESPAWN_BEHIND:
            far_z -= SEGMENT_LENGTH
            segment.position.z = far_z

func generate() -> void:
    while next_row_z + position.z > -SPAWN_AHEAD:
        spawn_row(next_row_z)
        last_row_z = next_row_z
        var gap_time := maxf(0.85, 1.65 - minf(tier, 8) * 0.1)
        next_row_z -= maxf(current_speed, 16.0) * gap_time

func make_holder(surface: int, z: float) -> Node3D:
    var holder := Node3D.new()
    holder.rotation.z = surface * PI * 0.5
    holder.position.z = z
    add_child(holder)
    return holder

func pick_kind(level: int) -> int:
    var roll := randf()
    if level == 0:
        return Kind.HIGH if roll < 0.55 else Kind.LOW
    if roll < 0.2:
        return Kind.LASER
    if roll < 0.5:
        return Kind.HIGH
    if roll < 0.75:
        return Kind.LOW
    return Kind.GAP

func spawn_row(z: float) -> void:
    var row := Row.new()
    row.z = z
    var has_previous := not rows.is_empty()
    var level := mini(tier, 8)
    if level >= 2 and randf() < 0.18:
        add_spinner(z)
        rows.append(row)
        return
    var previous_safe := last_safe
    var step: int = [-1, 0, 1].pick_random()
    var safe := posmod(last_safe + step, 4)
    last_safe = safe
    var block_chance := minf(0.45 + level * 0.07, 0.85)
    for surface in 4:
        if surface == safe:
            if level >= 1 and randf() < 0.25:
                add_obstacle(Kind.LOW, surface, z)
                row.lows.append(surface)
            continue
        if randf() < block_chance:
            var kind := pick_kind(level)
            add_obstacle(kind, surface, z)
            row.blocked.append(surface)
            if kind == Kind.LOW or kind == Kind.GAP:
                row.lows.append(surface)
    rows.append(row)
    if has_previous:
        spawn_pickups(z, previous_safe, safe)

func spawn_pickups(z: float, from_surface: int, to_surface: int) -> void:
    var middle := (z + last_row_z) * 0.5
    var roll := randf()
    if roll < 0.08:
        add_power(to_surface, middle)
    elif roll < 0.8:
        for i in 5:
            var orb_surface := from_surface if i < 3 else to_surface
            var orb_height := 0.9 + sin(float(i) / 4.0 * PI) * 1.1
            add_orb(orb_surface, middle + (2 - i) * 2.2, orb_height)

func add_obstacle(kind: int, surface: int, z: float) -> void:
    var holder := make_holder(surface, z)
    var item := Item.new()
    item.kind = kind
    item.surface = surface
    item.z = z
    item.node = holder
    match kind:
        Kind.HIGH:
            Fx.box(holder, Vector3(4.8, 2.4, 0.9), Vector3(0.0, -HALF + 1.2, 0.0), hazard_red)
            Fx.box(holder, Vector3(0.3, 2.6, 1.1), Vector3(-2.55, -HALF + 1.3, 0.0), frame_material)
            Fx.box(holder, Vector3(0.3, 2.6, 1.1), Vector3(2.55, -HALF + 1.3, 0.0), frame_material)
            Fx.box(holder, Vector3(5.4, 0.16, 1.2), Vector3(0.0, -HALF + 2.5, 0.0), hot_material)
            Fx.box(holder, Vector3(4.6, 0.08, 1.0), Vector3(0.0, -HALF + 0.05, 0.0), danger_material)
        Kind.LOW:
            Fx.box(holder, Vector3(4.8, 0.9, 1.0), Vector3(0.0, -HALF + 0.45, 0.0), hazard_amber)
            Fx.box(holder, Vector3(5.0, 0.1, 1.2), Vector3(0.0, -HALF + 0.92, 0.0), low_material)
        Kind.GAP:
            Fx.box(holder, Vector3(4.2, 0.05, 2.2), Vector3(0.0, -HALF + 0.03, 0.0), pit_material)
            Fx.box(holder, Vector3(4.4, 0.08, 0.12), Vector3(0.0, -HALF + 0.06, -1.15), danger_material)
            Fx.box(holder, Vector3(4.4, 0.08, 0.12), Vector3(0.0, -HALF + 0.06, 1.15), danger_material)
            Fx.box(holder, Vector3(0.12, 0.08, 2.4), Vector3(-2.2, -HALF + 0.06, 0.0), danger_material)
            Fx.box(holder, Vector3(0.12, 0.08, 2.4), Vector3(2.2, -HALF + 0.06, 0.0), danger_material)
        Kind.LASER:
            Fx.cylinder(holder, 0.2, 1.9, Vector3(-2.5, -HALF + 0.95, 0.0), Vector3.ZERO, frame_material)
            Fx.cylinder(holder, 0.2, 1.9, Vector3(2.5, -HALF + 0.95, 0.0), Vector3.ZERO, frame_material)
            Fx.sphere(holder, 0.1, Vector3(-2.5, -HALF + 1.95, 0.0), laser_material)
            Fx.sphere(holder, 0.1, Vector3(2.5, -HALF + 1.95, 0.0), laser_material)
            var beams := Node3D.new()
            holder.add_child(beams)
            for beam_height: float in [0.3, 0.95, 1.6]:
                Fx.box(beams, Vector3(4.8, 0.05, 0.05), Vector3(0.0, -HALF + beam_height, 0.0), hot_material)
                Fx.box(beams, Vector3(4.8, 0.18, 0.18), Vector3(0.0, -HALF + beam_height, 0.0), laser_halo_material)
            item.visual = beams
            item.phase = randf() * LASER_PERIOD
    items.append(item)

func add_spinner(z: float) -> void:
    var holder := Node3D.new()
    holder.position.z = z
    add_child(holder)
    Fx.cylinder(holder, 0.5, 0.8, Vector3.ZERO, Vector3(90.0, 0.0, 0.0), frame_material)
    Fx.sphere(holder, 0.22, Vector3(0.0, 0.0, -0.42), danger_material)
    Fx.box(holder, Vector3(HALF * 2.0 - 0.3, 0.3, 0.45), Vector3.ZERO, hazard_amber)
    Fx.box(holder, Vector3(0.3, 0.4, 0.55), Vector3(HALF - 0.3, 0.0, 0.0), danger_material)
    Fx.box(holder, Vector3(0.3, 0.4, 0.55), Vector3(-HALF + 0.3, 0.0, 0.0), danger_material)
    var item := Item.new()
    item.kind = Kind.SPINNER
    item.surface = -1
    item.z = z
    item.node = holder
    item.phase = randf() * TAU
    item.spin = SPIN_RATE if randf() < 0.5 else -SPIN_RATE
    items.append(item)

func add_orb(surface: int, z: float, height: float) -> void:
    var holder := make_holder(surface, z)
    var orb := Node3D.new()
    orb.position = Vector3(0.0, -HALF + height, 0.0)
    holder.add_child(orb)
    Fx.sphere(orb, 0.15, Vector3.ZERO, orb_core_material)
    Fx.sphere(orb, 0.3, Vector3.ZERO, orb_shell_material)
    var item := Item.new()
    item.kind = Kind.ORB
    item.surface = surface
    item.z = z
    item.height = height
    item.node = holder
    item.visual = orb
    items.append(item)

func add_power(surface: int, z: float) -> void:
    var holder := make_holder(surface, z)
    var item := Item.new()
    item.kind = Kind.POWER
    item.surface = surface
    item.z = z
    item.height = 1.2
    item.power = randi() % 3
    item.node = holder
    var crystal := Node3D.new()
    crystal.position = Vector3(0.0, -HALF + 1.2, 0.0)
    holder.add_child(crystal)
    Fx.box(crystal, Vector3(0.32, 0.32, 0.32), Vector3.ZERO, power_materials[item.power])
    Fx.box(crystal, Vector3(0.56, 0.56, 0.56), Vector3.ZERO, power_shells[item.power])
    item.visual = crystal
    items.append(item)

func update_items(delta: float) -> void:
    for index in range(items.size() - 1, -1, -1):
        var item := items[index]
        var relative := item.z + position.z
        if relative > DESPAWN_BEHIND:
            item.node.queue_free()
            items.remove_at(index)
            continue
        match item.kind:
            Kind.HIGH:
                check_obstacle(item, relative, true)
            Kind.LOW:
                check_obstacle(item, relative, player_height < 0.85)
            Kind.GAP:
                check_obstacle(item, relative, player_height < 0.5)
            Kind.LASER:
                var active := laser_active(item)
                item.visual.visible = active
                check_obstacle(item, relative, active)
            Kind.SPINNER:
                item.node.rotation.z = item.phase + clock * item.spin
                check_obstacle(item, relative, spinner_aligned(item), true)
            Kind.ORB:
                update_orb(item, relative)
            Kind.POWER:
                update_power(item, relative, delta)
        if item.collected:
            items.remove_at(index)

func laser_active(item: Item) -> bool:
    return fposmod(clock + item.phase, LASER_PERIOD) < LASER_PERIOD * 0.55

func spinner_aligned(item: Item) -> bool:
    var player_angle := -PI * 0.5 + player_surface * PI * 0.5
    var difference := fposmod(item.node.rotation.z - player_angle, PI)
    return minf(difference, PI - difference) < 0.3

func check_obstacle(item: Item, relative: float, blocking: bool, any_surface: bool = false) -> void:
    if item.done or not collisions or not blocking:
        return
    if absf(relative) > 0.85:
        return
    if not any_surface and item.surface != player_surface:
        return
    item.done = true
    player_hit.emit(item.kind)

func update_orb(item: Item, relative: float) -> void:
    item.visual.scale = Vector3.ONE * (1.0 + 0.15 * sin(clock * 7.0 + item.z))
    if not collisions:
        return
    var touching := absf(relative) < 1.0 and item.surface == player_surface and absf(item.height - (player_height + 0.6)) < 1.2
    var pulled := magnet and relative > -10.0 and relative < 1.0
    if touching or pulled:
        collect(item, Color(1.0, 0.85, 0.2))
        orb_collected.emit()

func update_power(item: Item, relative: float, delta: float) -> void:
    item.visual.rotation += Vector3(1.4, 2.2, 0.0) * delta
    if not collisions:
        return
    if absf(relative) < 1.1 and item.surface == player_surface and absf(item.height - (player_height + 0.6)) < 1.5:
        collect(item, Color(1.0, 1.0, 1.0))
        power_collected.emit(item.power)

func collect(item: Item, color: Color) -> void:
    item.collected = true
    var burst_position := item.node.transform * item.visual.position
    Fx.burst(self, burst_position, color, 14, 5.0, 0.1, 0.6)
    item.node.queue_free()

func judge_rows() -> void:
    for row in rows:
        if row.judged:
            continue
        if row.z + position.z < 1.0:
            break
        row.judged = true
        if collisions:
            row_passed.emit(is_near_miss(row))

func is_near_miss(row: Row) -> bool:
    var dodged := since_shift < 0.5 and row.blocked.has(previous_surface) and not row.blocked.has(player_surface)
    var cleared := row.lows.has(player_surface) and player_height > 0.35
    return dodged or cleared

func clean_rows() -> void:
    while not rows.is_empty() and rows[0].z + position.z > DESPAWN_BEHIND:
        rows.remove_at(0)
