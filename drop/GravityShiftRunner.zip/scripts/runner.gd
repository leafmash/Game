class_name Runner
extends Node3D

const FLOOR_Y := -3.0

var flip_node: Node3D
var body: Node3D
var left_hip: Node3D
var right_hip: Node3D
var left_knee: Node3D
var right_knee: Node3D
var left_shoulder: Node3D
var right_shoulder: Node3D
var left_elbow: Node3D
var right_elbow: Node3D
var shield: MeshInstance3D
var shadow: MeshInstance3D
var shadow_material: StandardMaterial3D
var thrusters: CPUParticles3D
var sparks: CPUParticles3D
var flip_tween: Tween
var phase := 0.0
var alive := true

func _ready() -> void:
    flip_node = Node3D.new()
    flip_node.position = Vector3(0.0, 0.7, 0.0)
    add_child(flip_node)
    body = Node3D.new()
    body.position = Vector3(0.0, -0.7, 0.0)
    body.rotation.x = -0.14
    flip_node.add_child(body)
    build_parts()
    build_effects()

func make_joint(parent: Node3D, pos: Vector3) -> Node3D:
    var joint := Node3D.new()
    joint.position = pos
    parent.add_child(joint)
    return joint

func build_leg(x: float, suit: Material, armor: Material) -> Array[Node3D]:
    var hip := make_joint(body, Vector3(x, 0.55, 0.0))
    Fx.box(hip, Vector3(0.15, 0.28, 0.17), Vector3(0.0, -0.14, 0.0), suit)
    var knee := make_joint(hip, Vector3(0.0, -0.28, 0.0))
    Fx.sphere(knee, 0.085, Vector3.ZERO, armor)
    Fx.box(knee, Vector3(0.13, 0.28, 0.15), Vector3(0.0, -0.14, 0.0), armor)
    Fx.box(knee, Vector3(0.16, 0.1, 0.27), Vector3(0.0, -0.26, -0.05), suit)
    var result: Array[Node3D] = [hip, knee]
    return result

func build_arm(x: float, suit: Material, armor: Material) -> Array[Node3D]:
    var shoulder := make_joint(body, Vector3(x, 1.1, 0.0))
    Fx.sphere(shoulder, 0.12, Vector3.ZERO, armor)
    Fx.box(shoulder, Vector3(0.11, 0.24, 0.12), Vector3(0.0, -0.12, 0.0), suit)
    var elbow := make_joint(shoulder, Vector3(0.0, -0.24, 0.0))
    Fx.box(elbow, Vector3(0.1, 0.22, 0.11), Vector3(0.0, -0.11, 0.0), suit)
    Fx.sphere(elbow, 0.07, Vector3(0.0, -0.24, 0.0), armor)
    var result: Array[Node3D] = [shoulder, elbow]
    return result

func build_parts() -> void:
    var suit := Fx.lit_material(Color(0.82, 0.86, 0.95), 0.55, 0.38)
    var armor := Fx.lit_material(Color(0.12, 0.14, 0.22), 0.7, 0.3)
    var glow := Fx.glow_material(Color(0.1, 0.9, 1.0))
    var visor := Fx.emissive_material(Color(0.1, 0.8, 1.0), 1.3)
    var torso := CapsuleMesh.new()
    torso.radius = 0.24
    torso.height = 0.72
    var torso_instance := MeshInstance3D.new()
    torso_instance.mesh = torso
    torso_instance.material_override = suit
    torso_instance.position = Vector3(0.0, 0.8, 0.0)
    body.add_child(torso_instance)
    Fx.box(body, Vector3(0.46, 0.3, 0.3), Vector3(0.0, 0.95, -0.04), armor)
    Fx.box(body, Vector3(0.4, 0.14, 0.28), Vector3(0.0, 0.55, 0.0), armor)
    Fx.box(body, Vector3(0.26, 0.05, 0.05), Vector3(0.0, 1.0, -0.2), glow)
    Fx.sphere(body, 0.2, Vector3(0.0, 1.4, 0.0), armor)
    Fx.box(body, Vector3(0.28, 0.12, 0.14), Vector3(0.0, 1.42, -0.15), visor)
    Fx.box(body, Vector3(0.38, 0.46, 0.2), Vector3(0.0, 0.9, 0.27), armor)
    Fx.cylinder(body, 0.06, 0.14, Vector3(0.1, 0.68, 0.37), Vector3(90.0, 0.0, 0.0), glow)
    Fx.cylinder(body, 0.06, 0.14, Vector3(-0.1, 0.68, 0.37), Vector3(90.0, 0.0, 0.0), glow)
    var left_leg := build_leg(-0.12, suit, armor)
    var right_leg := build_leg(0.12, suit, armor)
    left_hip = left_leg[0]
    left_knee = left_leg[1]
    right_hip = right_leg[0]
    right_knee = right_leg[1]
    var left_arm := build_arm(-0.31, suit, armor)
    var right_arm := build_arm(0.31, suit, armor)
    left_shoulder = left_arm[0]
    left_elbow = left_arm[1]
    right_shoulder = right_arm[0]
    right_elbow = right_arm[1]

func make_trail(color: Color, size: float, amount: int, lifetime: float) -> CPUParticles3D:
    var particles := CPUParticles3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = size
    mesh.height = size * 2.0
    mesh.radial_segments = 6
    mesh.rings = 3
    mesh.material = Fx.glow_material(color)
    var curve := Curve.new()
    curve.add_point(Vector2(0.0, 1.0))
    curve.add_point(Vector2(1.0, 0.0))
    particles.mesh = mesh
    particles.scale_amount_curve = curve
    particles.amount = amount
    particles.lifetime = lifetime
    particles.gravity = Vector3.ZERO
    particles.emitting = true
    add_child(particles)
    return particles

func build_effects() -> void:
    shield = Fx.sphere(self, 1.0, Vector3(0.0, 0.7, 0.0), Fx.glow_material(Color(0.2, 0.9, 1.0), 0.25))
    shield.visible = false
    var quad := QuadMesh.new()
    quad.size = Vector2(1.4, 1.4)
    quad.orientation = PlaneMesh.FACE_Y
    shadow_material = StandardMaterial3D.new()
    shadow_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    shadow_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    shadow_material.albedo_texture = Surfaces.radial_texture(Color(0.0, 0.0, 0.0, 0.7), Color(0.0, 0.0, 0.0, 0.0))
    shadow = MeshInstance3D.new()
    shadow.mesh = quad
    shadow.material_override = shadow_material
    shadow.position = Vector3(0.0, 0.04, 0.0)
    add_child(shadow)
    thrusters = make_trail(Color(0.3, 0.9, 1.0), 0.07, 22, 0.45)
    thrusters.position = Vector3(0.0, 0.75, 0.4)
    thrusters.direction = Vector3(0.0, 0.0, 1.0)
    thrusters.spread = 8.0
    thrusters.initial_velocity_min = 4.0
    thrusters.initial_velocity_max = 7.0
    sparks = make_trail(Color(1.0, 0.65, 0.2), 0.035, 14, 0.35)
    sparks.position = Vector3(0.0, 0.05, 0.15)
    sparks.direction = Vector3(0.0, 0.6, 1.0)
    sparks.spread = 25.0
    sparks.initial_velocity_min = 5.0
    sparks.initial_velocity_max = 9.0
    sparks.gravity = Vector3(0.0, -14.0, 0.0)

func ease_to(joint: Node3D, target: float, blend: float) -> void:
    joint.rotation.x = lerpf(joint.rotation.x, target, blend)

func animate(delta: float, speed: float, in_air: bool) -> void:
    if not alive:
        return
    phase += delta * (7.0 + speed * 0.3)
    var blend := minf(14.0 * delta, 1.0)
    if in_air:
        ease_to(left_hip, 1.2, blend)
        ease_to(right_hip, -0.4, blend)
        ease_to(left_knee, -1.0, blend)
        ease_to(right_knee, -0.5, blend)
        ease_to(left_shoulder, 2.5, blend)
        ease_to(right_shoulder, 2.5, blend)
        ease_to(left_elbow, 0.4, blend)
        ease_to(right_elbow, 0.4, blend)
        body.position.y = -0.7
    else:
        var swing := sin(phase)
        left_hip.rotation.x = swing * 0.95
        right_hip.rotation.x = -swing * 0.95
        left_knee.rotation.x = -(0.25 + 0.9 * maxf(cos(phase), 0.0))
        right_knee.rotation.x = -(0.25 + 0.9 * maxf(-cos(phase), 0.0))
        left_shoulder.rotation.x = -swing * 0.8
        right_shoulder.rotation.x = swing * 0.8
        left_elbow.rotation.x = 0.9
        right_elbow.rotation.x = 0.9
        body.position.y = -0.7 + absf(sin(phase)) * 0.07
    sparks.emitting = not in_air
    if shield.visible:
        shield.scale = Vector3.ONE * (1.0 + sin(phase * 0.8) * 0.04)

func set_height(value: float) -> void:
    position.y = FLOOR_Y + value
    shadow.position.y = -value + 0.04
    shadow.scale = Vector3.ONE * (1.0 - minf(value * 0.2, 0.5))
    shadow_material.albedo_color.a = 1.0 - minf(value * 0.25, 0.6)

func flip() -> void:
    if flip_tween:
        flip_tween.kill()
    flip_node.rotation.x = 0.0
    flip_tween = create_tween()
    flip_tween.tween_property(flip_node, "rotation:x", -TAU, 0.32).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    flip_tween.tween_callback(reset_flip)

func reset_flip() -> void:
    flip_node.rotation.x = 0.0

func set_shield(enabled: bool) -> void:
    shield.visible = enabled

func crash() -> void:
    alive = false
    body.visible = false
    shield.visible = false
    shadow.visible = false
    thrusters.emitting = false
    sparks.emitting = false

func revive() -> void:
    alive = true
    body.visible = true
    shadow.visible = true
    thrusters.emitting = true

func reset() -> void:
    if flip_tween:
        flip_tween.kill()
    flip_node.rotation.x = 0.0
    alive = true
    body.visible = true
    shadow.visible = true
    shield.visible = false
    thrusters.emitting = true
    set_height(0.0)
