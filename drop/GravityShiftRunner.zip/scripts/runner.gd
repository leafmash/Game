class_name Runner
extends Node3D

var flip_node: Node3D
var body: Node3D
var left_leg: Node3D
var right_leg: Node3D
var left_arm: Node3D
var right_arm: Node3D
var shield: MeshInstance3D
var flip_tween: Tween
var phase := 0.0
var alive := true

func _ready() -> void:
    flip_node = Node3D.new()
    flip_node.position = Vector3(0.0, 0.7, 0.0)
    add_child(flip_node)
    body = Node3D.new()
    body.position = Vector3(0.0, -0.7, 0.0)
    body.rotation.x = -0.14
    flip_node.add_child(body)
    build_parts()
    shield = Fx.sphere(self, 1.0, Vector3(0.0, 0.7, 0.0), Fx.glow_material(Color(0.2, 0.9, 1.0), 0.28))
    shield.visible = false

func add_mesh(parent: Node3D, mesh: Mesh, pos: Vector3, material: Material) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    parent.add_child(instance)
    return instance

func make_limb(pos: Vector3, size: Vector3, material: Material) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = pos
    body.add_child(pivot)
    var mesh := BoxMesh.new()
    mesh.size = size
    add_mesh(pivot, mesh, Vector3(0.0, -size.y * 0.5, 0.0), material)
    return pivot

func build_parts() -> void:
    var suit := Fx.solid_material(Color(0.92, 0.94, 1.0), 0.4)
    var dark := Fx.solid_material(Color(0.15, 0.17, 0.3), 0.5)
    var accent := Fx.glow_material(Color(0.1, 0.9, 1.0))
    var torso := CapsuleMesh.new()
    torso.radius = 0.26
    torso.height = 0.8
    add_mesh(body, torso, Vector3(0.0, 0.75, 0.0), suit)
    var head := SphereMesh.new()
    head.radius = 0.22
    head.height = 0.44
    add_mesh(body, head, Vector3(0.0, 1.38, 0.0), suit)
    var visor := BoxMesh.new()
    visor.size = Vector3(0.3, 0.1, 0.12)
    add_mesh(body, visor, Vector3(0.0, 1.4, -0.17), accent)
    var pack := BoxMesh.new()
    pack.size = Vector3(0.4, 0.4, 0.2)
    add_mesh(body, pack, Vector3(0.0, 0.85, 0.28), dark)
    var stripe := BoxMesh.new()
    stripe.size = Vector3(0.44, 0.08, 0.26)
    add_mesh(body, stripe, Vector3(0.0, 0.85, 0.28), accent)
    left_leg = make_limb(Vector3(-0.13, 0.42, 0.0), Vector3(0.17, 0.44, 0.19), dark)
    right_leg = make_limb(Vector3(0.13, 0.42, 0.0), Vector3(0.17, 0.44, 0.19), dark)
    left_arm = make_limb(Vector3(-0.34, 1.05, 0.0), Vector3(0.12, 0.4, 0.14), suit)
    right_arm = make_limb(Vector3(0.34, 1.05, 0.0), Vector3(0.12, 0.4, 0.14), suit)

func animate(delta: float, speed: float, in_air: bool) -> void:
    if not alive:
        return
    phase += delta * (7.0 + speed * 0.3)
    var blend := minf(12.0 * delta, 1.0)
    if in_air:
        left_leg.rotation.x = lerpf(left_leg.rotation.x, 1.0, blend)
        right_leg.rotation.x = lerpf(right_leg.rotation.x, -0.5, blend)
        left_arm.rotation.x = lerpf(left_arm.rotation.x, 2.4, blend)
        right_arm.rotation.x = lerpf(right_arm.rotation.x, 2.4, blend)
        body.position.y = -0.7
    else:
        var swing := sin(phase) * 0.95
        left_leg.rotation.x = swing
        right_leg.rotation.x = -swing
        left_arm.rotation.x = -swing * 0.8
        right_arm.rotation.x = swing * 0.8
        body.position.y = -0.7 + absf(sin(phase)) * 0.07
    if shield.visible:
        shield.scale = Vector3.ONE * (1.0 + sin(phase * 0.8) * 0.04)

func flip() -> void:
    if flip_tween:
        flip_tween.kill()
    flip_node.rotation.x = 0.0
    flip_tween = create_tween()
    flip_tween.tween_property(flip_node, "rotation:x", -TAU, 0.32).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    flip_tween.tween_callback(reset_flip)

func reset_flip() -> void:
    flip_node.rotation.x = 0.0

func set_shield(enabled: bool) -> void:
    shield.visible = enabled

func crash() -> void:
    alive = false
    body.visible = false
    shield.visible = false

func revive() -> void:
    alive = true
    body.visible = true

func reset() -> void:
    if flip_tween:
        flip_tween.kill()
    flip_node.rotation.x = 0.0
    alive = true
    body.visible = true
    shield.visible = false
