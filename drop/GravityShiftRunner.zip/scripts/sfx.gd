extends Node

const RATE := 22050
const MUSIC_RATE := 16000
const POOL_SIZE := 8

var streams: Dictionary = {}
var pool: Array[AudioStreamPlayer] = []
var pool_index := 0
var music_player: AudioStreamPlayer
var music_tween: Tween

func _ready() -> void:
    streams["shift"] = synth(0.3, 700.0, 160.0, 2, 0.45, 0.6, 0.25)
    streams["orb"] = synth(0.18, 880.0, 1760.0, 0, 0.5)
    streams["jump"] = synth(0.22, 300.0, 720.0, 1, 0.3)
    streams["crash"] = synth(0.8, 240.0, 40.0, 2, 0.8, 0.6, 0.5)
    streams["power"] = synth(0.4, 500.0, 1300.0, 0, 0.5)
    streams["click"] = synth(0.06, 700.0, 500.0, 0, 0.4)
    streams["near"] = synth(0.25, 1200.0, 600.0, 1, 0.25)
    streams["shield_break"] = synth(0.35, 900.0, 200.0, 1, 0.45, 0.4, 0.5)
    for i in POOL_SIZE:
        var player := AudioStreamPlayer.new()
        add_child(player)
        pool.append(player)
    music_player = AudioStreamPlayer.new()
    music_player.stream = build_music()
    add_child(music_player)
    apply_volumes()

func synth(duration: float, freq_start: float, freq_end: float, wave: int, volume: float, noise_mix: float = 0.0, smooth: float = 0.0) -> AudioStreamWAV:
    var count := int(duration * RATE)
    var data := PackedByteArray()
    data.resize(count * 2)
    var phase := 0.0
    var filtered := 0.0
    for i in count:
        var t := float(i) / float(count)
        phase += lerpf(freq_start, freq_end, t) / float(RATE)
        var cycle := fposmod(phase, 1.0)
        var tone := 0.0
        if wave == 0:
            tone = sin(cycle * TAU)
        elif wave == 1:
            tone = 1.0 if cycle < 0.5 else -1.0
        else:
            tone = cycle * 2.0 - 1.0
        var raw := lerpf(tone, randf() * 2.0 - 1.0, noise_mix)
        if smooth > 0.0:
            filtered += (raw - filtered) * smooth
            raw = filtered
        var envelope := minf(float(i) / 120.0, 1.0) * pow(1.0 - t, 2.0)
        data.encode_s16(i * 2, int(clampf(raw * envelope * volume, -1.0, 1.0) * 32000.0))
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = RATE
    stream.stereo = false
    stream.data = data
    return stream

func build_music() -> AudioStreamWAV:
    var step_len := int(0.125 * MUSIC_RATE)
    var steps := 64
    var count := step_len * steps
    var roots := [110.0, 87.31, 130.81, 98.0]
    var thirds := [1.1892, 1.2599, 1.2599, 1.2599]
    var pattern := [0, 1, 2, 3, 2, 1, 2, 3, 0, 1, 2, 3, 2, 1, 3, 2]
    var data := PackedByteArray()
    data.resize(count * 2)
    for step in steps:
        var chord := floori(step / 16.0) % 4
        var root: float = roots[chord]
        var ratios := [1.0, thirds[chord], 1.4983, 2.0]
        var arp_ratio: float = ratios[pattern[step % 16]]
        var arp_freq := root * 2.0 * arp_ratio
        var kick := step % 4 == 0
        var hat := step % 2 == 1
        for j in step_len:
            var t := float(j) / float(step_len)
            var seconds := float(j) / float(MUSIC_RATE)
            var time := float(step * step_len + j) / float(MUSIC_RATE)
            var sample := 0.2 * (1.0 if fposmod(time * root, 1.0) < 0.5 else -1.0) * (1.0 - t * 0.5)
            sample += 0.14 * (fposmod(time * arp_freq, 1.0) * 2.0 - 1.0) * (1.0 - t)
            if kick:
                sample += 0.5 * sin(TAU * 55.0 * seconds * (1.0 + 3.0 * exp(-seconds * 40.0))) * exp(-seconds * 18.0)
            if hat:
                sample += 0.08 * (randf() * 2.0 - 1.0) * exp(-seconds * 60.0)
            data.encode_s16((step * step_len + j) * 2, int(clampf(sample, -1.0, 1.0) * 30000.0))
    var stream := AudioStreamWAV.new()
    stream.format = AudioStreamWAV.FORMAT_16_BITS
    stream.mix_rate = MUSIC_RATE
    stream.stereo = false
    stream.data = data
    stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    stream.loop_begin = 0
    stream.loop_end = count
    return stream

func play(sound: String, pitch: float = 1.0) -> void:
    if Save.sfx_volume <= 0.0 or not streams.has(sound):
        return
    var player := pool[pool_index]
    pool_index = (pool_index + 1) % POOL_SIZE
    player.stream = streams[sound]
    player.pitch_scale = pitch
    player.volume_db = linear_to_db(Save.sfx_volume)
    player.play()

func apply_volumes() -> void:
    music_player.volume_db = linear_to_db(maxf(Save.music_volume * 0.5, 0.0001))

func start_music() -> void:
    if music_tween:
        music_tween.kill()
    apply_volumes()
    music_player.stream_paused = false
    if not music_player.playing:
        music_player.play()

func stop_music() -> void:
    if music_tween:
        music_tween.kill()
    music_player.stop()

func pause_music(paused: bool) -> void:
    music_player.stream_paused = paused

func set_intensity(amount: float) -> void:
    music_player.pitch_scale = 1.0 + clampf(amount, 0.0, 1.0) * 0.25

func duck_music() -> void:
    if music_tween:
        music_tween.kill()
    music_tween = create_tween()
    music_tween.tween_property(music_player, "volume_db", -40.0, 0.6)
