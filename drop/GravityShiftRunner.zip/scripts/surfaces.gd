class_name Surfaces
extends RefCounted

static var cache: Dictionary = {}

static func noise(x: float, y: float) -> float:
    return fposmod(sin(x * 12.9898 + y * 78.233) * 43758.5453, 1.0)

static func panel_textures() -> Array[Texture2D]:
    if cache.has("panel"):
        return cache["panel"]
    var size := 128
    var albedo := Image.create_empty(size, size, false, Image.FORMAT_RGB8)
    var bump := Image.create_empty(size, size, false, Image.FORMAT_RGB8)
    for y in size:
        for x in size:
            var plate_x := x % 64
            var plate_y := y % 64
            var edge := mini(mini(plate_x, 63 - plate_x), mini(plate_y, 63 - plate_y))
            var relief := 0.6
            if edge < 2:
                relief = 0.05
            elif edge < 6:
                relief = 0.3 + float(edge - 2) * 0.075
            var rx := minf(absf(plate_x - 9.0), absf(plate_x - 54.0))
            var ry := minf(absf(plate_y - 9.0), absf(plate_y - 54.0))
            var rivet := clampf(1.0 - sqrt(rx * rx + ry * ry) / 3.5, 0.0, 1.0)
            var grain := noise(float(x), float(y)) * 0.05
            var streak := 0.9 + 0.1 * noise(floorf(x / 2.0), 3.0)
            var height := clampf(relief + rivet * 0.35 + grain, 0.0, 1.0)
            var shade := (0.35 + relief * 0.65 + rivet * 0.2) * streak
            albedo.set_pixel(x, y, Color(shade * 0.92, shade * 0.96, shade))
            bump.set_pixel(x, y, Color(height, height, height))
    bump.bump_map_to_normal_map(6.0)
    albedo.generate_mipmaps()
    bump.generate_mipmaps()
    var result: Array[Texture2D] = [ImageTexture.create_from_image(albedo), ImageTexture.create_from_image(bump)]
    cache["panel"] = result
    return result

static func stripe_texture(color_a: Color, color_b: Color) -> ImageTexture:
    var key := "stripe%s%s" % [color_a, color_b]
    if cache.has(key):
        return cache[key]
    var size := 64
    var image := Image.create_empty(size, size, false, Image.FORMAT_RGB8)
    for y in size:
        for x in size:
            var band := fposmod(float(x + y) / 16.0, 2.0)
            var base := color_a if band < 1.0 else color_b
            var wear := 0.85 + 0.15 * noise(float(x), float(y))
            image.set_pixel(x, y, Color(base.r * wear, base.g * wear, base.b * wear))
    image.generate_mipmaps()
    var texture := ImageTexture.create_from_image(image)
    cache[key] = texture
    return texture

static func radial_texture(inner: Color, outer: Color, size: int = 64) -> GradientTexture2D:
    var gradient := Gradient.new()
    gradient.set_color(0, inner)
    gradient.set_color(1, outer)
    var texture := GradientTexture2D.new()
    texture.gradient = gradient
    texture.fill = GradientTexture2D.FILL_RADIAL
    texture.fill_from = Vector2(0.5, 0.5)
    texture.fill_to = Vector2(1.0, 0.5)
    texture.width = size
    texture.height = size
    return texture

static func hazard(color_a: Color, color_b: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_texture = stripe_texture(color_a.darkened(0.25), color_b)
    material.metallic = 0.35
    material.roughness = 0.55
    material.emission_enabled = true
    material.emission = Color.WHITE
    material.emission_texture = stripe_texture(color_a, Color.BLACK)
    material.emission_energy_multiplier = 0.9
    material.uv1_triplanar = true
    material.uv1_scale = Vector3(0.7, 0.7, 0.7)
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    return material
